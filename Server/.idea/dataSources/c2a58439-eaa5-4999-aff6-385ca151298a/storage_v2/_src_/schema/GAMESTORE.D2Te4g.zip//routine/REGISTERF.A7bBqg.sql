create function registerF ( v_username IN VARCHAR , v_email IN VARCHAR)
return VARCHAR
IS
  V_response VARCHAR(50);
  V_id INT;
BEGIN

    select nvl((select 1  from Clients where v_username= username or v_email = email),0) into V_response from dual;
    if (V_response = '0') then
      V_response := 'Succes';
    else
      V_response := 'Error';
    end if;

    return V_Response;
END;
/

