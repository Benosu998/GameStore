create function get_gameName(actual_game_id int)
return varchar as
lista varchar(10000); 
begin
  select nume||'/'||pret||'/'||oferta||'/'||round(get_rating(actual_game_id),2)||'/'||get_game_categories(actual_game_id) into lista from games where id=actual_game_id;
  return lista;
end;
/

