create function get_games_by_category(actual_category varchar)
return varchar as
cursor games is
select distinct game_id from categories where category=actual_category;
lista varchar(10000);
actual_game int;
begin
open games;
loop
fetch games into actual_game;
exit when games%notfound;
lista:=lista||' '||actual_game;

end loop;
return lista;
end;
/

