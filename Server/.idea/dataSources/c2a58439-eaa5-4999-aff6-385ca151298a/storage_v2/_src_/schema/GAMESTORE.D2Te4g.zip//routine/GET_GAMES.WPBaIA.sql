create function get_games(actual_user_name varchar)
return varchar as
lista varchar(10000);
actual_game_id int;
cursor jocuri is
select game_id  from libraryes where user_id=(select id from clients where username = actual_user_name); 
begin
open jocuri;
loop
fetch jocuri into actual_game_id ;
  exit when jocuri%notfound;
lista:=lista||' '||actual_game_id;
end loop;
  return lista;
end;
/

