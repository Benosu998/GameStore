create function wallet ( v_username IN VARCHAR )
  return VARCHAR
IS
  v_response VARCHAR(1000);
BEGIN
  select wallet into v_response from Clients where username = v_username ;
  return v_response;
END;
/

