create function getGameFranchises
return varchar as
cursor franchises is
select nume from game_sequels;
  v_nume varchar(100);
 response varchar(300);
begin
open franchises;
loop
fetch franchises into v_nume;
exit when franchises%notfound;
response := response ||v_nume||'|';
end loop;
return response;
end;
/

