create function get_categories
return varchar as
lista varchar(10000);
actual_game_category varchar(100);
cursor categorii is
select distinct category from categories; 
begin
open categorii;
loop
fetch categorii into actual_game_category ;
exit when categorii%notfound;
lista:=lista||'/'||actual_game_category;
end loop;
  return lista;
end;
/

