create function get_rating(actual_game_id int)
return float as
response float;
begin
select sum(stars)/count(stars) into response from reviews where game_id=actual_game_id;
  return response;
end;
/

