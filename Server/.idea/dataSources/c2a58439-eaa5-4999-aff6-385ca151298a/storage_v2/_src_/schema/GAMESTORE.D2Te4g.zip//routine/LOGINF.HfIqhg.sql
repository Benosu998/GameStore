create function loginF ( v_username IN VARCHAR , v_pass IN VARCHAR)
return VARCHAR
IS 
  v_response VARCHAR(1000);
BEGIN
  select username || ' '||wallet into v_response from Clients where username = v_username and password = v_pass;
  
END;
/

