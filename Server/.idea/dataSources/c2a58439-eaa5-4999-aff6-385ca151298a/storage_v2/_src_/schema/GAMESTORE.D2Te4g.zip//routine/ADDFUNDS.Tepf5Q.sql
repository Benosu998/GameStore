create procedure addFunds(v_username in VARCHAR,v_value in INT,v_paymentMethod in VARCHAR)
as
   v_wallet Int;
begin
  select wallet into v_wallet from clients where username = v_username;
  v_wallet := v_wallet + v_value;
  update clients set wallet = v_wallet,PAYMENT_METHOD = v_paymentMethod
  where username = v_username;
end;
/

