create trigger HISTORYCHANGE
  before insert or update
  on LIBRARYES
  for each row
DECLARE
  v_id_game int;
  v_id_user int;
BEGIN 

  INSERT INTO history VALUES 
  (:new.user_id,:new.game_id, sysdate); 

END;
/

