create function get_games_by_name(actual_name varchar)
return varchar as
cursor games is
select distinct id from games where lower(nume) like '%'||lower(actual_name)||'%' ;
lista varchar(10000);
actual_game int;
begin
open games;
loop
fetch games into actual_game;
exit when games%notfound;
lista:=lista||' '||actual_game;

end loop;
return lista;
end;
/

