create procedure registerP(v_username in varchar ,v_password in varchar,  v_email in varchar)
as
  V_id INT;
begin
      select max(id)+1 into V_id from clients;
      insert into clients values(V_id,v_username,v_password,v_email,null,0);
end;
/

