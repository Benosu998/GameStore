create function getComents(v_game_id in int)
  return varchar2
is
  v_response varchar2(5000);
  cursor coments is
  select reviewer_id,stars,message from reviews where game_id = v_game_id;
  v_id int;
  v_stars number;
  v_message varchar(50);
  v_reviewer_name varchar2(100);
begin
  open coments;
  loop
    fetch coments into v_id,v_stars,v_message ;
    exit when coments%notfound;
    select username into v_reviewer_name from clients where id = v_id;
    v_response :=  v_response ||v_reviewer_name  ||'|'|| v_stars ||'|' ;
  end loop;
  return v_response;

end;
/

